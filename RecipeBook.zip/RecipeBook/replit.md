# Overview

This is a mobile-optimized Gemini AI-powered notebook application built with React, Express.js, and TypeScript. The application provides an interactive coding environment similar to Jupyter notebooks but specifically designed for mobile devices and integrated with Google's Gemini AI API. Users can create and execute code cells, write markdown documentation, and leverage AI assistance for code generation and text processing.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: TanStack Query for server state and local React state for UI
- **Routing**: Wouter for lightweight client-side routing
- **Mobile Optimization**: Touch gestures, swipe navigation, responsive design with mobile-first approach

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon Database)
- **API Design**: RESTful API with structured routes for notebooks and cells
- **Development**: Hot module replacement with Vite integration in development mode

## Data Storage Solutions
- **Primary Database**: PostgreSQL with two main tables:
  - `notebooks`: Store notebook metadata (id, title, timestamps)
  - `cells`: Store individual cell content (id, notebook_id, type, content, metadata, position)
- **Local Storage**: Browser localStorage for offline mode and auto-save functionality
- **Session Storage**: In-memory storage fallback for development/demo purposes

## Authentication and Authorization
- **Current State**: No authentication system implemented
- **Session Management**: Basic Express session configuration present but not actively used
- **Security**: CORS and basic request validation in place

## External Dependencies

### AI Services
- **Google Gemini API**: Primary AI service for code generation and text processing
  - Uses `@google/generative-ai` SDK
  - Supports both text generation and code-specific prompts
  - Configured for Gemini 2.5 Flash model

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting
  - Uses `@neondatabase/serverless` for connection pooling
  - Configured with connection string from environment variables

### Development Tools
- **Replit Integration**: Custom Vite plugins for Replit development environment
- **Monaco Editor**: Code editing capabilities with syntax highlighting
- **Speech Recognition**: Web Speech API for voice input functionality

### UI and Styling
- **Radix UI**: Headless UI components for accessibility and interaction patterns
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Font Awesome**: Icon library for UI elements
- **Various fonts**: Google Fonts integration (Inter, Fira Code, etc.)

### Build and Development
- **Vite**: Build tool and development server
- **TypeScript**: Type checking and development experience
- **ESBuild**: Fast JavaScript bundling for production builds
- **PostCSS**: CSS processing with Tailwind and Autoprefixer

The application supports both online and offline modes, with automatic synchronization when connectivity is restored. The architecture is designed to be mobile-responsive with touch-friendly interfaces and optimized for small screen interactions.