import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(
  process.env.GEMINI_API_KEY || 
  process.env.API_KEY || 
  ""
);

export interface GeminiResponse {
  text: string;
  success: boolean;
  error?: string;
}

export class GeminiService {
  private model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

  async generateText(prompt: string): Promise<GeminiResponse> {
    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      
      return {
        text: response.text(),
        success: true,
      };
    } catch (error) {
      console.error('Gemini API error:', error);
      return {
        text: "",
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred",
      };
    }
  }

  async generateCode(description: string, language: string = "javascript"): Promise<GeminiResponse> {
    const prompt = `Generate ${language} code for the following description. Only return the code without explanations or markdown formatting:\n\n${description}`;
    
    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      
      return {
        text: response.text(),
        success: true,
      };
    } catch (error) {
      console.error('Gemini code generation error:', error);
      return {
        text: "",
        success: false,
        error: error instanceof Error ? error.message : "Code generation failed",
      };
    }
  }

  async analyzeImage(imageBase64: string, prompt: string = "Describe this image in detail"): Promise<GeminiResponse> {
    try {
      const imageParts = {
        inlineData: {
          data: imageBase64.replace(/^data:image\/[a-z]+;base64,/, ''),
          mimeType: "image/jpeg",
        },
      };

      const result = await this.model.generateContent([prompt, imageParts]);
      const response = await result.response;
      
      return {
        text: response.text(),
        success: true,
      };
    } catch (error) {
      console.error('Gemini image analysis error:', error);
      return {
        text: "",
        success: false,
        error: error instanceof Error ? error.message : "Image analysis failed",
      };
    }
  }

  async executeCode(code: string, language: string): Promise<GeminiResponse> {
    const prompt = `Analyze this ${language} code and predict what it would output when executed. If there are any errors, explain them:\n\n\`\`\`${language}\n${code}\n\`\`\``;
    
    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      
      return {
        text: response.text(),
        success: true,
      };
    } catch (error) {
      console.error('Gemini code execution analysis error:', error);
      return {
        text: "",
        success: false,
        error: error instanceof Error ? error.message : "Code analysis failed",
      };
    }
  }
}

export const geminiService = new GeminiService();
