import { type Notebook, type Cell, type InsertNotebook, type InsertCell, type UpdateCell } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Notebooks
  getNotebook(id: string): Promise<Notebook | undefined>;
  createNotebook(notebook: InsertNotebook): Promise<Notebook>;
  updateNotebook(id: string, notebook: Partial<InsertNotebook>): Promise<Notebook | undefined>;
  deleteNotebook(id: string): Promise<boolean>;
  
  // Cells
  getCell(id: string): Promise<Cell | undefined>;
  getCellsByNotebook(notebookId: string): Promise<Cell[]>;
  createCell(cell: InsertCell): Promise<Cell>;
  updateCell(id: string, cell: UpdateCell): Promise<Cell | undefined>;
  deleteCell(id: string): Promise<boolean>;
  reorderCells(notebookId: string, cellIds: string[]): Promise<void>;
}

export class MemStorage implements IStorage {
  private notebooks: Map<string, Notebook>;
  private cells: Map<string, Cell>;

  constructor() {
    this.notebooks = new Map();
    this.cells = new Map();
    
    // Create a default notebook for demo
    this.initializeDefaultNotebook();
  }

  private async initializeDefaultNotebook() {
    const defaultNotebook = await this.createNotebook({ title: "Welcome to Gemini Notebook" });
    
    // Create welcome cells
    await this.createCell({
      notebookId: defaultNotebook.id,
      type: 'markdown',
      content: '# Welcome to Gemini Notebook\n\nThis is a mobile-optimized notebook for working with the Gemini AI API.',
      metadata: {},
      position: 0,
    });

    await this.createCell({
      notebookId: defaultNotebook.id,
      type: 'code',
      content: '// Import Gemini API\nimport { GoogleGenerativeAI } from "@google/generative-ai";\n\nconst genAI = new GoogleGenerativeAI("YOUR_API_KEY");\nconst model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });',
      metadata: { language: 'javascript' },
      position: 1,
    });
  }

  // Notebooks
  async getNotebook(id: string): Promise<Notebook | undefined> {
    return this.notebooks.get(id);
  }

  async createNotebook(insertNotebook: InsertNotebook): Promise<Notebook> {
    const id = randomUUID();
    const now = new Date();
    const notebook: Notebook = { 
      id, 
      title: insertNotebook.title || "Untitled Notebook",
      createdAt: now, 
      updatedAt: now 
    };
    this.notebooks.set(id, notebook);
    return notebook;
  }

  async updateNotebook(id: string, notebook: Partial<InsertNotebook>): Promise<Notebook | undefined> {
    const existing = this.notebooks.get(id);
    if (!existing) return undefined;
    
    const updated: Notebook = {
      ...existing,
      ...notebook,
      updatedAt: new Date(),
    };
    this.notebooks.set(id, updated);
    return updated;
  }

  async deleteNotebook(id: string): Promise<boolean> {
    const deleted = this.notebooks.delete(id);
    // Also delete all cells in this notebook
    const cellsToDelete: string[] = [];
    for (const [cellId, cell] of this.cells.entries()) {
      if (cell.notebookId === id) {
        cellsToDelete.push(cellId);
      }
    }
    cellsToDelete.forEach(cellId => this.cells.delete(cellId));
    return deleted;
  }

  // Cells
  async getCell(id: string): Promise<Cell | undefined> {
    return this.cells.get(id);
  }

  async getCellsByNotebook(notebookId: string): Promise<Cell[]> {
    return Array.from(this.cells.values())
      .filter(cell => cell.notebookId === notebookId)
      .sort((a, b) => a.position - b.position);
  }

  async createCell(insertCell: InsertCell): Promise<Cell> {
    const id = randomUUID();
    const now = new Date();
    const cell: Cell = { 
      id, 
      notebookId: insertCell.notebookId,
      type: insertCell.type,
      content: insertCell.content || "",
      metadata: insertCell.metadata || {},
      position: insertCell.position || 0,
      createdAt: now, 
      updatedAt: now 
    };
    this.cells.set(id, cell);
    return cell;
  }

  async updateCell(id: string, updateCell: UpdateCell): Promise<Cell | undefined> {
    const existing = this.cells.get(id);
    if (!existing) return undefined;
    
    const updated: Cell = {
      ...existing,
      ...updateCell,
      updatedAt: new Date(),
    };
    this.cells.set(id, updated);
    return updated;
  }

  async deleteCell(id: string): Promise<boolean> {
    return this.cells.delete(id);
  }

  async reorderCells(notebookId: string, cellIds: string[]): Promise<void> {
    const cells = await this.getCellsByNotebook(notebookId);
    
    cellIds.forEach((cellId, index) => {
      const cell = this.cells.get(cellId);
      if (cell && cell.notebookId === notebookId) {
        this.cells.set(cellId, { ...cell, position: index, updatedAt: new Date() });
      }
    });
  }
}

export const storage = new MemStorage();
