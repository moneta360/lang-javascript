import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { geminiService } from "./services/gemini";
import { insertNotebookSchema, insertCellSchema, updateCellSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Notebooks
  app.get("/api/notebooks/:id", async (req, res) => {
    try {
      const notebook = await storage.getNotebook(req.params.id);
      if (!notebook) {
        return res.status(404).json({ message: "Notebook not found" });
      }
      res.json(notebook);
    } catch (error) {
      res.status(500).json({ message: "Failed to get notebook" });
    }
  });

  app.post("/api/notebooks", async (req, res) => {
    try {
      const notebook = insertNotebookSchema.parse(req.body);
      const created = await storage.createNotebook(notebook);
      res.status(201).json(created);
    } catch (error) {
      res.status(400).json({ message: "Invalid notebook data" });
    }
  });

  app.put("/api/notebooks/:id", async (req, res) => {
    try {
      const notebook = insertNotebookSchema.partial().parse(req.body);
      const updated = await storage.updateNotebook(req.params.id, notebook);
      if (!updated) {
        return res.status(404).json({ message: "Notebook not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(400).json({ message: "Invalid notebook data" });
    }
  });

  // Cells
  app.get("/api/notebooks/:notebookId/cells", async (req, res) => {
    try {
      const cells = await storage.getCellsByNotebook(req.params.notebookId);
      res.json(cells);
    } catch (error) {
      res.status(500).json({ message: "Failed to get cells" });
    }
  });

  app.post("/api/cells", async (req, res) => {
    try {
      const cell = insertCellSchema.parse(req.body);
      const created = await storage.createCell(cell);
      res.status(201).json(created);
    } catch (error) {
      res.status(400).json({ message: "Invalid cell data" });
    }
  });

  app.put("/api/cells/:id", async (req, res) => {
    try {
      const cell = updateCellSchema.parse(req.body);
      const updated = await storage.updateCell(req.params.id, cell);
      if (!updated) {
        return res.status(404).json({ message: "Cell not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(400).json({ message: "Invalid cell data" });
    }
  });

  app.delete("/api/cells/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteCell(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Cell not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete cell" });
    }
  });

  // Gemini API endpoints
  app.post("/api/gemini/generate", async (req, res) => {
    try {
      const { prompt } = req.body;
      if (!prompt) {
        return res.status(400).json({ message: "Prompt is required" });
      }
      const result = await geminiService.generateText(prompt);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate text" });
    }
  });

  app.post("/api/gemini/generate-code", async (req, res) => {
    try {
      const { description, language = "javascript" } = req.body;
      if (!description) {
        return res.status(400).json({ message: "Description is required" });
      }
      const result = await geminiService.generateCode(description, language);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate code" });
    }
  });

  app.post("/api/gemini/analyze-image", async (req, res) => {
    try {
      const { imageBase64, prompt = "Describe this image in detail" } = req.body;
      if (!imageBase64) {
        return res.status(400).json({ message: "Image data is required" });
      }
      const result = await geminiService.analyzeImage(imageBase64, prompt);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to analyze image" });
    }
  });

  app.post("/api/gemini/execute-code", async (req, res) => {
    try {
      const { code, language } = req.body;
      if (!code || !language) {
        return res.status(400).json({ message: "Code and language are required" });
      }
      const result = await geminiService.executeCode(code, language);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to analyze code" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
