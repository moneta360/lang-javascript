import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const notebooks = pgTable("notebooks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull().default("Untitled Notebook"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const cells = pgTable("cells", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  notebookId: varchar("notebook_id").references(() => notebooks.id).notNull(),
  type: varchar("type").notNull(), // 'code', 'markdown', 'output'
  content: text("content").notNull().default(""),
  metadata: jsonb("metadata").default({}), // for language, execution status, etc.
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertNotebookSchema = createInsertSchema(notebooks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCellSchema = createInsertSchema(cells).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateCellSchema = createInsertSchema(cells).omit({
  id: true,
  notebookId: true,
  createdAt: true,
  updatedAt: true,
}).partial();

export type InsertNotebook = z.infer<typeof insertNotebookSchema>;
export type InsertCell = z.infer<typeof insertCellSchema>;
export type UpdateCell = z.infer<typeof updateCellSchema>;
export type Notebook = typeof notebooks.$inferSelect;
export type Cell = typeof cells.$inferSelect;

export const CellType = z.enum(['code', 'markdown', 'output']);
export type CellType = z.infer<typeof CellType>;
