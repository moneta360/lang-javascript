import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useVoiceInput } from '@/hooks/use-voice-input';
import { cn } from '@/lib/utils';

interface VoiceInputProps {
  onTranscript: (transcript: string) => void;
  className?: string;
}

export function VoiceInput({ onTranscript, className }: VoiceInputProps) {
  const { isListening, transcript, error, isSupported, startListening, stopListening, clearTranscript } = useVoiceInput();
  const [language, setLanguage] = useState('uk-UA');

  const handleToggle = () => {
    if (isListening) {
      stopListening();
      if (transcript) {
        onTranscript(transcript);
        clearTranscript();
      }
    } else {
      startListening(language);
    }
  };

  if (!isSupported) {
    return (
      <Button
        variant="outline"
        size="sm"
        disabled
        className={cn("w-8 h-8 p-0", className)}
        data-testid="voice-input-unsupported"
      >
        <i className="fas fa-microphone-slash text-gray-500 text-xs" />
      </Button>
    );
  }

  return (
    <div className="flex items-center space-x-2">
      <Button
        variant={isListening ? "destructive" : "outline"}
        size="sm"
        onClick={handleToggle}
        className={cn(
          "w-8 h-8 p-0 transition-all",
          isListening && "animate-pulse",
          className
        )}
        data-testid="voice-input-toggle"
      >
        <i className={cn(
          "text-xs",
          isListening ? "fas fa-stop text-white" : "fas fa-microphone text-gray-300"
        )} />
      </Button>

      {isListening && (
        <div className="text-xs text-red-400 animate-pulse" data-testid="voice-listening-indicator">
          Слухаю...
        </div>
      )}

      {error && (
        <div className="text-xs text-red-400" data-testid="voice-error">
          {error}
        </div>
      )}
    </div>
  );
}
