import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { CodeEditor } from './CodeEditor';
import { Textarea } from '@/components/ui/textarea';
import { useSwipe } from '@/hooks/use-swipe';
import { cn } from '@/lib/utils';
import type { Cell } from '@shared/schema';

interface NotebookCellProps {
  cell: Cell;
  index: number;
  onUpdate: (id: string, content: string, metadata?: any) => void;
  onDelete: (id: string) => void;
  onExecute: (id: string) => void;
  onDuplicate: (cell: Cell) => void;
  isExecuting?: boolean;
  executionResult?: string;
  executionError?: string;
}

export function NotebookCell({ 
  cell, 
  index, 
  onUpdate, 
  onDelete, 
  onExecute, 
  onDuplicate, 
  isExecuting = false,
  executionResult,
  executionError
}: NotebookCellProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showOutput, setShowOutput] = useState(true);
  const cardRef = useRef<HTMLDivElement>(null);

  const swipeHandlers = useSwipe({
    onSwipeLeft: () => {
      // TODO: Implement swipe to next cell
      console.log('Swipe left - next cell');
    },
    onSwipeRight: () => {
      // TODO: Implement swipe to previous cell
      console.log('Swipe right - previous cell');
    }
  });

  const getCellTypeIcon = (type: string) => {
    switch (type) {
      case 'code':
        return { icon: 'fas fa-code', color: 'text-sky-400', bgColor: 'bg-sky-500/20', borderColor: 'border-sky-500/30' };
      case 'markdown':
        return { icon: 'fab fa-markdown', color: 'text-purple-400', bgColor: 'bg-purple-500/20', borderColor: 'border-purple-500/30' };
      case 'output':
        return { icon: 'fas fa-terminal', color: 'text-green-400', bgColor: 'bg-green-500/20', borderColor: 'border-green-500/30' };
      default:
        return { icon: 'fas fa-file', color: 'text-gray-400', bgColor: 'bg-gray-500/20', borderColor: 'border-gray-500/30' };
    }
  };

  const typeInfo = getCellTypeIcon(cell.type);

  const handleExecute = () => {
    if (cell.type === 'code') {
      onExecute(cell.id);
    } else if (cell.type === 'markdown') {
      // For markdown, just toggle preview
      setShowOutput(!showOutput);
    }
  };

  const renderCellContent = () => {
    switch (cell.type) {
      case 'code':
        return (
          <CodeEditor
            value={cell.content}
            onChange={(value) => onUpdate(cell.id, value, cell.metadata)}
            language={(cell.metadata as any)?.language || 'javascript'}
            onExecute={handleExecute}
            isExecuting={isExecuting}
          />
        );

      case 'markdown':
        return (
          <div className="bg-gray-900 rounded-lg border border-gray-700 overflow-hidden">
            <div className="bg-gray-800 px-3 py-2 border-b border-gray-700 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <i className="fab fa-markdown text-blue-400 text-sm" />
                <span className="text-xs text-gray-400">Markdown</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowOutput(!showOutput)}
                className="w-8 h-8 p-0 bg-blue-600 hover:bg-blue-500 border-blue-600"
                data-testid={`render-markdown-${cell.id}`}
              >
                <i className={cn("text-white text-xs", showOutput ? "fas fa-edit" : "fas fa-eye")} />
              </Button>
            </div>
            <div className="p-3">
              {showOutput ? (
                <div className="prose prose-invert prose-sm max-w-none">
                  {cell.content.split('\n').map((line, i) => (
                    <div key={i} className="text-gray-100 text-sm leading-relaxed">
                      {line.startsWith('#') ? (
                        <h3 className="text-lg font-semibold text-sky-400 mb-2">{line.replace(/^#+\s*/, '')}</h3>
                      ) : line.startsWith('-') || line.startsWith('*') ? (
                        <li className="list-disc list-inside text-gray-300">{line.replace(/^[-*]\s*/, '')}</li>
                      ) : (
                        <p className="mb-3">{line}</p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <Textarea
                  value={cell.content}
                  onChange={(e) => onUpdate(cell.id, e.target.value, cell.metadata)}
                  placeholder="# Введіть markdown..."
                  className="w-full bg-transparent text-gray-100 font-mono text-sm leading-relaxed resize-none border-none outline-none placeholder-gray-500 min-h-[100px]"
                  data-testid={`markdown-textarea-${cell.id}`}
                />
              )}
            </div>
          </div>
        );

      default:
        return (
          <Textarea
            value={cell.content}
            onChange={(e) => onUpdate(cell.id, e.target.value, cell.metadata)}
            placeholder="Введіть текст..."
            className="w-full bg-gray-900 text-gray-100 font-mono text-sm leading-relaxed resize-none border border-gray-700 rounded-lg p-3 placeholder-gray-500 min-h-[100px]"
            data-testid={`text-textarea-${cell.id}`}
          />
        );
    }
  };

  const hasOutput = executionResult || executionError;

  return (
    <Card 
      ref={cardRef}
      className="border-b border-gray-800/50 bg-transparent border-l-0 border-r-0 border-t-0 rounded-none relative"
      data-testid={`cell-${cell.id}`}
      {...swipeHandlers}
    >
      <CardContent className="p-4">
        {/* Cell Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <div className={cn(
              "w-6 h-6 rounded border flex items-center justify-center",
              typeInfo.bgColor,
              typeInfo.borderColor
            )}>
              <span className={cn("text-xs font-mono", typeInfo.color)}>{index + 1}</span>
            </div>
            <span className="text-sm text-gray-400 font-medium capitalize">{cell.type}</span>
            {isExecuting && (
              <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" title="Виконується" />
            )}
            {hasOutput && !isExecuting && (
              <div className="w-2 h-2 bg-green-400 rounded-full" title="Виконано" />
            )}
          </div>
          
          <DropdownMenu open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="w-8 h-8 p-0 hover:bg-gray-800"
                data-testid={`cell-menu-${cell.id}`}
              >
                <i className="fas fa-ellipsis-v text-gray-400 text-sm" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-48 bg-gray-800 border-gray-700">
              <DropdownMenuItem
                onClick={() => onDuplicate(cell)}
                className="text-gray-300 hover:bg-gray-700"
                data-testid={`duplicate-cell-${cell.id}`}
              >
                <i className="fas fa-copy mr-2" />
                Дублювати
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => onDelete(cell.id)}
                className="text-red-400 hover:bg-gray-700"
                data-testid={`delete-cell-${cell.id}`}
              >
                <i className="fas fa-trash mr-2" />
                Видалити
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Cell Content */}
        {renderCellContent()}

        {/* Output Section */}
        {hasOutput && (
          <div className="bg-gray-800/50 rounded-lg border border-gray-700/50 p-3 mt-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-400 font-medium">Вивід</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowOutput(!showOutput)}
                className="text-xs text-gray-500 hover:text-gray-300 h-auto p-1"
                data-testid={`toggle-output-${cell.id}`}
              >
                <i className={cn("fas", showOutput ? "fa-chevron-up" : "fa-chevron-down")} />
              </Button>
            </div>
            
            {showOutput && (
              <div className="text-sm font-mono" data-testid={`output-${cell.id}`}>
                {executionError ? (
                  <div className="text-red-400">{executionError}</div>
                ) : (
                  <div className="text-gray-300">{executionResult}</div>
                )}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
