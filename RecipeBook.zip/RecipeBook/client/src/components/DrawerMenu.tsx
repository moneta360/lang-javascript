import { Button } from '@/components/ui/button';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { cn } from '@/lib/utils';

interface DrawerMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onNewNotebook: () => void;
  onExport: () => void;
  onToggleVoiceInput: () => void;
  onToggleOfflineMode: () => void;
  isOfflineMode?: boolean;
}

export function DrawerMenu({ 
  isOpen, 
  onClose, 
  onNewNotebook, 
  onExport, 
  onToggleVoiceInput, 
  onToggleOfflineMode,
  isOfflineMode = false 
}: DrawerMenuProps) {
  
  const menuItems = [
    {
      category: "Файл",
      items: [
        {
          icon: "fas fa-plus text-sky-400",
          label: "Новий notebook",
          onClick: onNewNotebook,
          testId: "menu-new-notebook"
        },
        {
          icon: "fas fa-download text-green-400",
          label: "Експорт",
          onClick: onExport,
          testId: "menu-export"
        },
        {
          icon: "fas fa-share-alt text-purple-400",
          label: "Поділитися",
          onClick: () => {
            // TODO: Implement share functionality
            console.log('Share clicked');
          },
          testId: "menu-share"
        }
      ]
    },
    {
      category: "Шаблони",
      items: [
        {
          icon: "fas fa-robot text-sky-400",
          label: "Gemini Chat",
          onClick: () => {
            // TODO: Insert chat template
            console.log('Gemini chat template');
          },
          testId: "template-chat"
        },
        {
          icon: "fas fa-image text-yellow-400",
          label: "Аналіз зображень",
          onClick: () => {
            // TODO: Insert image analysis template
            console.log('Image analysis template');
          },
          testId: "template-image"
        },
        {
          icon: "fas fa-code text-green-400",
          label: "Генерація коду",
          onClick: () => {
            // TODO: Insert code generation template
            console.log('Code generation template');
          },
          testId: "template-code"
        }
      ]
    },
    {
      category: "Налаштування",
      items: [
        {
          icon: "fas fa-microphone text-red-400",
          label: "Голосовий ввід",
          onClick: onToggleVoiceInput,
          testId: "settings-voice"
        },
        {
          icon: cn("fas fa-wifi-slash", isOfflineMode ? "text-orange-400" : "text-gray-400"),
          label: "Офлайн режим",
          onClick: onToggleOfflineMode,
          testId: "settings-offline"
        },
        {
          icon: "fas fa-cog text-gray-400",
          label: "Налаштування",
          onClick: () => {
            // TODO: Open settings
            console.log('Settings clicked');
          },
          testId: "settings-general"
        }
      ]
    }
  ];

  return (
    <Drawer open={isOpen} onOpenChange={onClose}>
      <DrawerContent className="h-[90vh] bg-gray-900 border-gray-800">
        <DrawerHeader className="border-b border-gray-800">
          <DrawerTitle className="text-gray-100">Меню</DrawerTitle>
        </DrawerHeader>
        
        <div className="flex flex-col flex-1 overflow-y-auto">
          {menuItems.map((section) => (
            <div key={section.category} className="p-4 border-b border-gray-800">
              <h3 className="text-sm font-medium text-gray-400 mb-3 uppercase tracking-wide">
                {section.category}
              </h3>
              <div className="space-y-2">
                {section.items.map((item) => (
                  <Button
                    key={item.testId}
                    variant="ghost"
                    className="w-full justify-start p-3 h-auto text-left hover:bg-gray-800 active:bg-gray-700"
                    onClick={() => {
                      item.onClick();
                      onClose();
                    }}
                    data-testid={item.testId}
                  >
                    <i className={cn("w-5 mr-3", item.icon)} />
                    <span className="text-gray-300">{item.label}</span>
                  </Button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </DrawerContent>
    </Drawer>
  );
}
