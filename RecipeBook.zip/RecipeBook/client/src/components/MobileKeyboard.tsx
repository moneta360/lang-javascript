import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface MobileKeyboardProps {
  onInsertText: (text: string) => void;
  language?: string;
  isVisible: boolean;
  onToggle: () => void;
}

export function MobileKeyboard({ 
  onInsertText, 
  language = 'javascript', 
  isVisible, 
  onToggle 
}: MobileKeyboardProps) {
  const getQuickInserts = () => {
    switch (language.toLowerCase()) {
      case 'javascript':
      case 'js':
        return [
          { label: 'console.log()', text: 'console.log()' },
          { label: 'function', text: 'function () {\n  \n}' },
          { label: 'if', text: 'if () {\n  \n}' },
          { label: 'for', text: 'for (let i = 0; i < ; i++) {\n  \n}' },
          { label: 'const', text: 'const  = ' },
          { label: 'async', text: 'async function () {\n  \n}' },
          { label: '=>', text: ' => ' },
          { label: 'try/catch', text: 'try {\n  \n} catch (error) {\n  \n}' },
        ];
      case 'python':
        return [
          { label: 'print()', text: 'print()' },
          { label: 'def', text: 'def ():\n    ' },
          { label: 'if', text: 'if :\n    ' },
          { label: 'for', text: 'for  in :\n    ' },
          { label: 'import', text: 'import ' },
          { label: 'class', text: 'class :\n    def __init__(self):\n        ' },
        ];
      default:
        return [
          { label: '{}', text: '{}' },
          { label: '[]', text: '[]' },
          { label: '()', text: '()' },
          { label: ';', text: ';' },
          { label: ':', text: ':' },
          { label: '=', text: ' = ' },
        ];
    }
  };

  const quickInserts = getQuickInserts();

  if (!isVisible) {
    return (
      <div className="fixed bottom-20 right-4 z-50">
        <Button
          onClick={onToggle}
          className="rounded-full w-12 h-12 bg-gray-700 hover:bg-gray-600"
          data-testid="toggle-mobile-keyboard"
        >
          <i className="fas fa-keyboard text-white" />
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-20 left-0 right-0 bg-gray-800 border-t border-gray-700 p-3 z-50 safe-area-bottom">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm text-gray-400 font-medium">Швидкий ввід</span>
        <Button
          onClick={onToggle}
          variant="ghost"
          size="sm"
          className="text-gray-400"
          data-testid="close-mobile-keyboard"
        >
          <i className="fas fa-times" />
        </Button>
      </div>
      
      <div className="grid grid-cols-2 gap-2">
        {quickInserts.map((item, index) => (
          <Button
            key={index}
            onClick={() => onInsertText(item.text)}
            variant="outline"
            size="sm"
            className="text-left justify-start bg-gray-700 hover:bg-gray-600 border-gray-600 text-white touch-friendly"
            data-testid={`quick-insert-${index}`}
          >
            <span className="font-mono text-sm">{item.label}</span>
          </Button>
        ))}
      </div>
    </div>
  );
}