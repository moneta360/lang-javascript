import * as React from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface FloatingActionButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: "default" | "secondary";
  size?: "default" | "sm" | "lg";
}

const FloatingActionButton = React.forwardRef<HTMLButtonElement, FloatingActionButtonProps>(
  ({ className, children, variant = "default", size = "default", ...props }, ref) => {
    return (
      <Button
        ref={ref}
        className={cn(
          "fixed bottom-6 right-6 rounded-full shadow-xl transition-all duration-200 transform hover:scale-105 active:scale-95 z-50",
          {
            "w-14 h-14": size === "default",
            "w-12 h-12": size === "sm", 
            "w-16 h-16": size === "lg",
            "bg-sky-600 hover:bg-sky-500 active:bg-sky-700": variant === "default",
            "bg-gray-600 hover:bg-gray-500 active:bg-gray-700": variant === "secondary",
          },
          className
        )}
        {...props}
      >
        {children}
      </Button>
    );
  }
);

FloatingActionButton.displayName = "FloatingActionButton";

export { FloatingActionButton };
