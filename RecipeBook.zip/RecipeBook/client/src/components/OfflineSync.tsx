import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import type { Cell } from '@shared/schema';

interface OfflineSyncProps {
  isOfflineMode: boolean;
  onSyncComplete?: () => void;
}

export function OfflineSync({ isOfflineMode, onSyncComplete }: OfflineSyncProps) {
  const [localCells] = useLocalStorage<Cell[]>('notebook-cells', []);
  const [pendingSync, setPendingSync] = useLocalStorage('pending-sync', false);
  const [isSyncing, setIsSyncing] = useState(false);
  const { toast } = useToast();

  const hasUnsyncedChanges = pendingSync && localCells.length > 0;

  const syncToServer = async () => {
    if (isOfflineMode || !hasUnsyncedChanges) return;

    setIsSyncing(true);
    try {
      // Here you would implement actual sync logic
      // For now, we'll just simulate a sync
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setPendingSync(false);
      toast({
        title: "Синхронізація завершена",
        description: "Всі зміни збережено на сервері",
      });
      
      onSyncComplete?.();
    } catch (error) {
      toast({
        title: "Помилка синхронізації",
        description: "Не вдалося синхронізувати дані",
        variant: "destructive",
      });
    } finally {
      setIsSyncing(false);
    }
  };

  // Auto-sync when going online
  useEffect(() => {
    if (!isOfflineMode && hasUnsyncedChanges) {
      const timer = setTimeout(() => {
        syncToServer();
      }, 3000); // Auto-sync after 3 seconds when online

      return () => clearTimeout(timer);
    }
  }, [isOfflineMode, hasUnsyncedChanges]);

  if (isOfflineMode) {
    return (
      <Alert className="mx-4 mb-4 bg-orange-500/10 border-orange-500/50">
        <i className="fas fa-wifi-slash text-orange-400" />
        <AlertDescription className="text-orange-300">
          Працюєте в офлайн режимі. Зміни збережено локально.
        </AlertDescription>
      </Alert>
    );
  }

  if (hasUnsyncedChanges) {
    return (
      <Alert className="mx-4 mb-4 bg-blue-500/10 border-blue-500/50">
        <i className="fas fa-cloud-upload-alt text-blue-400" />
        <AlertDescription className="flex items-center justify-between text-blue-300">
          <span>Є незбережені зміни</span>
          <Button
            onClick={syncToServer}
            disabled={isSyncing}
            size="sm"
            variant="outline"
            className="ml-2 bg-blue-600 hover:bg-blue-500 border-blue-600"
            data-testid="sync-button"
          >
            {isSyncing ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2" />
                Синхронізація...
              </>
            ) : (
              <>
                <i className="fas fa-sync mr-2" />
                Синхронізувати
              </>
            )}
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  return null;
}