import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface MobileToolbarProps {
  onAddCode: () => void;
  onAddMarkdown: () => void;
  onRunAll?: () => void;
  onVoiceInput?: () => void;
  className?: string;
}

export function MobileToolbar({ 
  onAddCode, 
  onAddMarkdown, 
  onRunAll, 
  onVoiceInput,
  className 
}: MobileToolbarProps) {
  return (
    <div className={cn(
      "flex items-center justify-center space-x-2 p-3 bg-gray-900/90 backdrop-blur-sm border-t border-gray-800 sticky bottom-0 z-40",
      className
    )}>
      <Button
        onClick={onAddCode}
        size="sm"
        className="flex-1 bg-sky-600 hover:bg-sky-500 touch-friendly mobile-button"
        data-testid="mobile-add-code"
      >
        <i className="fas fa-code mr-2" />
        Код
      </Button>
      
      <Button
        onClick={onAddMarkdown}
        variant="outline"
        size="sm"
        className="flex-1 touch-friendly mobile-button"
        data-testid="mobile-add-markdown"
      >
        <i className="fab fa-markdown mr-2" />
        Текст
      </Button>
      
      {onRunAll && (
        <Button
          onClick={onRunAll}
          variant="outline"
          size="sm"
          className="bg-green-600 hover:bg-green-500 border-green-600 touch-friendly mobile-button"
          data-testid="mobile-run-all"
        >
          <i className="fas fa-play" />
        </Button>
      )}
      
      {onVoiceInput && (
        <Button
          onClick={onVoiceInput}
          variant="outline"
          size="sm"
          className="bg-red-600 hover:bg-red-500 border-red-600 touch-friendly mobile-button"
          data-testid="mobile-voice"
        >
          <i className="fas fa-microphone" />
        </Button>
      )}
    </div>
  );
}