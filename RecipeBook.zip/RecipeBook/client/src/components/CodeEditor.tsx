import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { VoiceInput } from './VoiceInput';
import { cn } from '@/lib/utils';

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  language?: string;
  onExecute?: () => void;
  isExecuting?: boolean;
  className?: string;
}

export function CodeEditor({ 
  value, 
  onChange, 
  language = 'javascript', 
  onExecute, 
  isExecuting = false,
  className 
}: CodeEditorProps) {
  const [showVoice, setShowVoice] = useState(false);

  const handleVoiceTranscript = (transcript: string) => {
    // Append voice transcript to existing content
    const newValue = value ? `${value}\n${transcript}` : transcript;
    onChange(newValue);
    setShowVoice(false);
  };

  const getLanguageIcon = (lang: string) => {
    switch (lang.toLowerCase()) {
      case 'javascript':
      case 'js':
        return 'fab fa-js-square text-yellow-400';
      case 'python':
        return 'fab fa-python text-blue-400';
      case 'html':
        return 'fab fa-html5 text-orange-400';
      case 'css':
        return 'fab fa-css3-alt text-blue-400';
      default:
        return 'fas fa-code text-gray-400';
    }
  };

  return (
    <div className={cn("bg-gray-900 rounded-lg border border-gray-700 overflow-hidden", className)}>
      {/* Header */}
      <div className="bg-gray-800 px-3 py-2 border-b border-gray-700 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <i className={cn("text-sm", getLanguageIcon(language))} />
          <span className="text-xs text-gray-400 capitalize">{language}</span>
        </div>
        <div className="flex items-center space-x-1">
          {onExecute && (
            <Button
              variant="outline"
              size="sm"
              onClick={onExecute}
              disabled={isExecuting}
              className="w-8 h-8 p-0 bg-green-600 hover:bg-green-500 border-green-600"
              data-testid="execute-code"
            >
              {isExecuting ? (
                <i className="fas fa-spinner fa-spin text-white text-xs" />
              ) : (
                <i className="fas fa-play text-white text-xs" />
              )}
            </Button>
          )}
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowVoice(!showVoice)}
            className="w-8 h-8 p-0"
            data-testid="toggle-voice-input"
          >
            <i className="fas fa-microphone text-gray-300 text-xs" />
          </Button>
        </div>
      </div>

      {/* Voice Input */}
      {showVoice && (
        <div className="bg-gray-800/50 px-3 py-2 border-b border-gray-700">
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-400">Голосовий ввід</span>
            <VoiceInput 
              onTranscript={handleVoiceTranscript} 
              className="w-6 h-6"
            />
          </div>
        </div>
      )}

      {/* Code Input */}
      <div className="p-3">
        <Textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={`// Введіть ${language} код...`}
          className="w-full bg-transparent text-gray-100 font-mono text-sm leading-relaxed resize-none border-none outline-none placeholder-gray-500 min-h-[100px]"
          data-testid="code-textarea"
        />
      </div>
    </div>
  );
}
