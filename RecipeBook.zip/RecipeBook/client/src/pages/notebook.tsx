import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { FloatingActionButton } from '@/components/ui/floating-action-button';
import { DrawerMenu } from '@/components/DrawerMenu';
import { NotebookCell } from '@/components/NotebookCell';
import { MobileToolbar } from '@/components/MobileToolbar';
import { MobileKeyboard } from '@/components/MobileKeyboard';
import { OfflineSync } from '@/components/OfflineSync';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';
import { apiRequest } from '@/lib/queryClient';
import type { Cell, Notebook } from '@shared/schema';

const DEFAULT_NOTEBOOK_ID = 'default';

export default function NotebookPage() {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isOfflineMode, setIsOfflineMode] = useLocalStorage('offline-mode', false);
  const [executingCells, setExecutingCells] = useState<Set<string>>(new Set());
  const [cellOutputs, setCellOutputs] = useLocalStorage<Record<string, { result?: string; error?: string }>>('cell-outputs', {});
  const [showMobileKeyboard, setShowMobileKeyboard] = useState(false);
  const [focusedCellId, setFocusedCellId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isMobile = useIsMobile();

  // Auto-save indicator
  const [lastSaved, setLastSaved] = useState<Date>(new Date());

  // Fetch cells
  const { data: cells = [], isLoading } = useQuery({
    queryKey: ['/api/notebooks', DEFAULT_NOTEBOOK_ID, 'cells'],
    enabled: !isOfflineMode,
  });

  const [localCells, setLocalCells] = useLocalStorage<Cell[]>('notebook-cells', []);

  const displayCells: Cell[] = isOfflineMode ? localCells : (cells || []);

  // Mutations
  const updateCellMutation = useMutation({
    mutationFn: async ({ id, content, metadata }: { id: string; content: string; metadata?: any }) => {
      if (isOfflineMode) {
        setLocalCells(prev => prev.map(cell => 
          cell.id === id ? { ...cell, content, metadata, updatedAt: new Date() } : cell
        ));
        return;
      }
      return await apiRequest('PUT', `/api/cells/${id}`, { content, metadata });
    },
    onSuccess: () => {
      setLastSaved(new Date());
      if (!isOfflineMode) {
        queryClient.invalidateQueries({ queryKey: ['/api/notebooks', DEFAULT_NOTEBOOK_ID, 'cells'] });
      }
    },
  });

  const createCellMutation = useMutation({
    mutationFn: async (cellData: { type: string; content: string; metadata?: any; position: number }) => {
      if (isOfflineMode) {
        const newCell: Cell = {
          id: `temp-${Date.now()}`,
          notebookId: DEFAULT_NOTEBOOK_ID,
          type: cellData.type,
          content: cellData.content,
          metadata: cellData.metadata || {},
          position: cellData.position,
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        setLocalCells(prev => [...prev, newCell].sort((a, b) => a.position - b.position));
        return newCell;
      }
      
      const response = await apiRequest('POST', '/api/cells', {
        notebookId: DEFAULT_NOTEBOOK_ID,
        ...cellData,
      });
      return response.json();
    },
    onSuccess: () => {
      if (!isOfflineMode) {
        queryClient.invalidateQueries({ queryKey: ['/api/notebooks', DEFAULT_NOTEBOOK_ID, 'cells'] });
      }
    },
  });

  const deleteCellMutation = useMutation({
    mutationFn: async (id: string) => {
      if (isOfflineMode) {
        setLocalCells(prev => prev.filter(cell => cell.id !== id));
        return;
      }
      return await apiRequest('DELETE', `/api/cells/${id}`);
    },
    onSuccess: () => {
      if (!isOfflineMode) {
        queryClient.invalidateQueries({ queryKey: ['/api/notebooks', DEFAULT_NOTEBOOK_ID, 'cells'] });
      }
    },
  });

  const executeCodeMutation = useMutation({
    mutationFn: async ({ code, language }: { code: string; language: string }) => {
      const response = await apiRequest('POST', '/api/gemini/execute-code', { code, language });
      return response.json();
    },
  });

  // Event handlers
  const handleUpdateCell = (id: string, content: string, metadata?: any) => {
    updateCellMutation.mutate({ id, content, metadata });
  };

  const handleDeleteCell = (id: string) => {
    deleteCellMutation.mutate(id);
    // Remove from outputs
    setCellOutputs(prev => {
      const newOutputs = { ...prev };
      delete newOutputs[id];
      return newOutputs;
    });
  };

  const handleExecuteCell = async (id: string) => {
    const cell = displayCells.find(c => c.id === id);
    if (!cell || cell.type !== 'code') return;

    if (isOfflineMode) {
      toast({
        title: "Офлайн режим",
        description: "Виконання коду недоступне в офлайн режимі",
        variant: "destructive",
      });
      return;
    }

    setExecutingCells(prev => new Set([...Array.from(prev), id]));
    
    try {
      const result = await executeCodeMutation.mutateAsync({
        code: cell.content,
        language: (cell.metadata as any)?.language || 'javascript',
      });

      setCellOutputs(prev => ({
        ...prev,
        [id]: result.success 
          ? { result: result.text }
          : { error: result.error || 'Execution failed' }
      }));
    } catch (error) {
      setCellOutputs(prev => ({
        ...prev,
        [id]: { error: 'Failed to execute code' }
      }));
    } finally {
      setExecutingCells(prev => {
        const next = new Set(Array.from(prev));
        next.delete(id);
        return next;
      });
    }
  };

  const handleDuplicateCell = (cell: Cell) => {
    createCellMutation.mutate({
      type: cell.type,
      content: cell.content,
      metadata: cell.metadata,
      position: displayCells.length,
    });
  };

  const handleAddCell = (type: 'code' | 'markdown' = 'code') => {
    const content = type === 'code' 
      ? '// Введіть JavaScript код...\n' 
      : '# Новий розділ\n\nВведіть markdown текст...';
      
    createCellMutation.mutate({
      type,
      content,
      metadata: type === 'code' ? { language: 'javascript' } : {},
      position: displayCells.length,
    });
  };

  const handleNewNotebook = () => {
    // TODO: Implement new notebook functionality
    toast({
      title: "Новий notebook",
      description: "Функція буде реалізована в наступній версії",
    });
  };

  const handleExport = () => {
    const data = {
      cells: displayCells,
      timestamp: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'gemini-notebook.json';
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Експорт завершено",
      description: "Notebook збережено у файл",
    });
  };

  const handleRunAllCells = async () => {
    const codeCells = displayCells.filter(cell => cell.type === 'code');
    for (const cell of codeCells) {
      await handleExecuteCell(cell.id);
    }
  };

  const handleInsertText = (text: string) => {
    if (focusedCellId) {
      const cell = displayCells.find(c => c.id === focusedCellId);
      if (cell) {
        const newContent = cell.content + text;
        handleUpdateCell(focusedCellId, newContent, cell.metadata);
      }
    }
  };

  if (isLoading && !isOfflineMode) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-spinner fa-spin text-4xl text-sky-400 mb-4" />
          <p className="text-gray-400">Завантажую notebook...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-gray-900/95 backdrop-blur-sm border-b border-gray-800 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsDrawerOpen(true)}
              className="w-11 h-11 bg-gray-800 hover:bg-gray-700 border-gray-700"
              data-testid="open-drawer"
            >
              <i className="fas fa-bars text-gray-300" />
            </Button>
            <div className="flex items-center space-x-2">
              <i className="fas fa-robot text-sky-400" />
              <h1 className="text-lg font-semibold text-gray-100">Gemini Notebook</h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {/* Auto-save indicator */}
            <div className="flex items-center space-x-1 text-xs text-gray-400" data-testid="auto-save-indicator">
              <i className={`fas fa-cloud-upload-alt text-green-400 ${updateCellMutation.isPending ? 'animate-pulse' : ''}`} />
              <span>
                {updateCellMutation.isPending ? 'Зберігаю...' : 'Збережено'}
              </span>
            </div>
            
            {isOfflineMode && (
              <div className="flex items-center space-x-1 text-xs text-orange-400" data-testid="offline-indicator">
                <i className="fas fa-wifi-slash" />
                <span>Офлайн</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Offline Sync Component */}
      <OfflineSync isOfflineMode={isOfflineMode} />

      {/* Welcome message - only show on desktop */}
      {!isMobile && (
        <div className="p-4 bg-gradient-to-r from-sky-500/10 to-purple-500/10 border-b border-gray-800">
          <div className="flex items-start space-x-3">
            <div className="flex-shrink-0 w-8 h-8 bg-sky-500/20 rounded-lg flex items-center justify-center">
              <i className="fas fa-lightbulb text-sky-400 text-sm" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-gray-300">
                Швайпніть вліво/вправо між комірками, довгий дотик для контекстного меню
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Notebook Cells */}
      <main className={`flex-1 ${isMobile ? 'pb-20' : ''}`}>
        {displayCells.length === 0 ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-file-code text-gray-400 text-2xl" />
            </div>
            <h3 className="text-lg font-semibold text-gray-300 mb-2">Порожній notebook</h3>
            <p className="text-gray-500 mb-6">Додайте першу комірку для початку роботи</p>
            <Button 
              onClick={() => handleAddCell('code')}
              className="bg-sky-600 hover:bg-sky-500"
              data-testid="add-first-cell"
            >
              <i className="fas fa-plus mr-2" />
              Додати код
            </Button>
          </div>
        ) : (
          displayCells.map((cell, index) => (
            <NotebookCell
              key={cell.id}
              cell={cell}
              index={index}
              onUpdate={handleUpdateCell}
              onDelete={handleDeleteCell}
              onExecute={handleExecuteCell}
              onDuplicate={handleDuplicateCell}
              isExecuting={executingCells.has(cell.id)}
              executionResult={cellOutputs[cell.id]?.result}
              executionError={cellOutputs[cell.id]?.error}
            />
          ))
        )}
      </main>

      {/* Mobile Toolbar */}
      {isMobile && (
        <MobileToolbar
          onAddCode={() => handleAddCell('code')}
          onAddMarkdown={() => handleAddCell('markdown')}
          onRunAll={handleRunAllCells}
          onVoiceInput={() => setShowMobileKeyboard(!showMobileKeyboard)}
        />
      )}

      {/* Floating Action Button - Desktop only */}
      {!isMobile && (
        <FloatingActionButton onClick={() => handleAddCell('code')} data-testid="fab-add-cell">
          <i className="fas fa-plus text-white text-xl" />
        </FloatingActionButton>
      )}

      {/* Mobile Keyboard */}
      {isMobile && (
        <MobileKeyboard
          onInsertText={handleInsertText}
          language={(displayCells.find(c => c.id === focusedCellId)?.metadata as any)?.language || 'javascript'}
          isVisible={showMobileKeyboard}
          onToggle={() => setShowMobileKeyboard(!showMobileKeyboard)}
        />
      )}

      {/* Drawer Menu */}
      <DrawerMenu
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        onNewNotebook={handleNewNotebook}
        onExport={handleExport}
        onToggleVoiceInput={() => {
          toast({
            title: "Голосовий ввід",
            description: "Використовуйте кнопку мікрофона в редакторі коду",
          });
        }}
        onToggleOfflineMode={() => setIsOfflineMode(!isOfflineMode)}
        isOfflineMode={isOfflineMode}
      />
    </div>
  );
}
